import csv
csv_file = open('binary_data.csv')
csv_reader = csv.reader(csv_file, delimiter=',')
result = []
for row in csv_reader:
    result.append(row)

for i in range(len(result)):
    for j in range(6):
        result[i][j] = int(result[i][j])

for var in result:
    print(var)

for s in range(2):
    num = 0
    for i in range(len(result)):
        if result[i][5] == s:
            num += 1
    p = num/len(result)
    print("p(l=%d)=%f" % (s, p))

x = 0
y = 0
for m in range(len(result)):
    if result[m][5] == 0:
        x += 1
    if result[m][5] == 1:
        y += 1

for i in range(5):
    num = 0
    for m in range(len(result)):
        if result[m][i] == 0 and result[m][5] == 0:
            num += 1
    p = num/x
    print("p(a%d=0|l=0)=%f" % (i, p))

for i in range(5):
    num = 0
    for m in range(len(result)):
        if result[m][i] == 1 and result[m][5] == 0:
            num += 1
    p = num/x
    print("p(a%d=1|l=0)=%f" % (i, p))

for i in range(5):
    num = 0
    for m in range(len(result)):
        if result[m][i] == 0 and result[m][5] == 1:
            num += 1
    p = num/y
    print("p(a%d=0|l=1)=%f" % (i, p))

for i in range(5):
    num = 0
    for m in range(len(result)):
        if result[m][i] == 1 and result[m][5] == 1:
            num += 1
    p = num/y
    print("p(a%d=1|l=1)=%f" % (i, p))

