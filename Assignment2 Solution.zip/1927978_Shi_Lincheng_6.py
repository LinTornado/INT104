import numpy as np
from nltk.stem.porter import *
import os
import math

# 1
path = "dataset"
split_list = []
dirs = os.listdir(path)
for i in dirs:
    datasets = os.listdir("./dataset/" + i)
    for txt in datasets:
        with open(os.path.join(path, i, txt), 'r', encoding='Latin1') as txt_open:
            txt_read = txt_open.read()
            split = txt_read.split()  # 按照空格分割
            split_list.append(split)
# print(split_list)

# 2
temporary_list1 = []
for i in split_list:
    split_list = [x.lower() for x in i]   # 小写
    temporary_list1.append(split_list)
    split_list = temporary_list1
# print(split_list)

temporary_list2 = []
for i in split_list:
    split_list = [re.sub("[^a-z]", "", x) for x in i]  # 去除非字母
    split_list = [x for x in split_list if x != '']
    temporary_list2.append(split_list)
    split_list = temporary_list2
# print(split_list)

with open("./stopwords.txt", 'r', encoding="utf8") as fp:
    stop_word = set(fp.read().split())
    split_list = [list(filter(lambda x: x not in stop_word, i)) for i in split_list]  # 去除stop word
# print(split_list)

# 3
temporary_list3 = []
stemmer = PorterStemmer()
for i in split_list:
    plurals = [x for x in i]
    singles = [stemmer.stem(plural) for plural in plurals]  # 去后缀
    temporary_list3.append(singles)
    split_list = temporary_list3
# print(split_list)

# 4
dict0 = {}
for num in range(len(split_list)):
    dict0[num] = {}
    for x in split_list[num]:
        if x not in dict0[num]:
            dict0[num][x] = 1
        else:
            dict0[num][x] += 1  # 第num+1个文件单词x出现的次数
# print(dict0[2725]['vat'])

# 5
dict1 = {}
for i in split_list:
    for x in i:
        dict1.update({x: 0})  # dict1相当于存储unique word的字典，值为出现的文档数
for w in dict1.keys():
    for i in split_list:
        if w in i:
            dict1[w] += 1  # 单词w出现的文档数
# print(dict1)

# 6
a = {}
for num in range(len(split_list)):
    a[num] = {}
    for x in dict1.keys():
        if x in split_list[num]:
            a[num][x] = dict0[num][x] * math.log(len(split_list) / dict1[x])
        else:
            a[num][x] = 0  # 求aik
        # print(a[num][x])
D = len(dict1)
N = len(split_list)
# print(D)
# print(N)
